function love.load()
    

end

function love.update(dt)

end

function love.draw()
    love.graphics.print("The game is running.")
end
